import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { DataService } from './data.service';
import { IntervieweeComponent } from './components/interviewee/interviewee.component';
import { DevColorCheckPipe } from './pipes';


@NgModule({
  declarations: [
    AppComponent, 
    IntervieweeComponent, 
    DevColorCheckPipe],
  imports: [BrowserModule, FormsModule],
  bootstrap: [AppComponent],
  providers: [DataService],
})
export class AppModule {}
