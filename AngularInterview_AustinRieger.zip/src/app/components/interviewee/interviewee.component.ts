import { Component, OnInit, OnDestroy} from '@angular/core';
import { DeveloperModel, DeveloperWithFoodModel, FoodModel } from 'src/app/model';
import { DataService } from 'src/app/data.service';
import { DevColorCheckPipe } from 'src/app/pipes';

@Component({
  selector: 'app-interviewee',
  templateUrl: './interviewee.component.html',
  styleUrls: ['./interviewee.component.scss']
})

/*
** 
**
**
**
*/
export class IntervieweeComponent implements OnInit {
  devData: DeveloperModel[] = [];
  foodData: FoodModel[] = [];
  devsFavFoodData: DeveloperWithFoodModel[] = [];

  constructor(private dataService: DataService) { }
  
  
  ngOnInit(): void {

    /*Description:
    **Pull in and subscribe to data from DataService

    **TODO --------------------------------------------------------------
    ** In the future, better unpack and use observables 
    */
    this.dataService.getDevelopersObservable.subscribe((devData) => this.devData = devData);
    this.dataService.getFavoriteFoodsObservable.subscribe((foodData) => this.foodData = foodData);


    /*
    ** Merge Favorite foods into 'DataWithFoodModel' array called devsFavFoodData
    ** This should move to a 'getArrayDeveloperWithFood() located in data.service.ts'
    ** If this was user input, there would need to be checks on the lengths, content, etc. 
    ** Change company for display to Danaher
    */
    var data:DeveloperWithFoodModel = this.devData[0] as DeveloperWithFoodModel 
    for (var dev of this.devData) {
      for (var food of this.foodData){
        if (dev.id == food.developerId){
         data = dev as DeveloperWithFoodModel
          data.foodName = food.name;
        }
      }
      data.company = "Danaher";
      this.devsFavFoodData.push(data);
    }
  }
}
