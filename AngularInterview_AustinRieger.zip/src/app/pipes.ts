import {Pipe, PipeTransform} from '@angular/core';
import { DeveloperModel, FoodModel } from './model';
import { DeveloperWithFoodModel } from './model';




/*********
* Filters color 
* Returns DeveloperModel array filled by those whose favorite color is red
*********/
@Pipe( {
    name: 'DevColorCheckPipe',
})

export class DevColorCheckPipe implements PipeTransform {
    transform(devs: DeveloperModel[]): DeveloperModel[] {
        let x:boolean = false;
        let groupRed:DeveloperModel[] = [];
        for (var dev of devs){
             if (dev.favoriteColor == "red")
            {
              groupRed.push(dev);
            }
        }
        return groupRed;
    }
}






/*********
* Merges 'DeveloperModel' with 'FoodModel' into 'DeveloperWithFoodModel'
* Changes 'company' name on the 'DeveloperWithFoodModel'
* 
* NOT IN USE- Decided to just change it in the JS for now.
*********/
@Pipe ({name: 'changeEmployer'})

export class changeEmployerPipe implements PipeTransform {
    
    transform(dev: DeveloperWithFoodModel, food:FoodModel): DeveloperWithFoodModel {
        dev.company = "Danaher";
        //devFood = dev;

        return dev
    }
}
